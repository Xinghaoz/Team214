from django.contrib import admin
from .views import *
# Register your models here.

class PlayRoleAdmin(admin.ModelAdmin):
	list_display = ('role_name', 'role_picture', 'init_wealth','init_gpa','init_strength','lucky')

admin.site.register(PlayRole, PlayRoleAdmin)

class PropertyAdmin(admin.ModelAdmin):
	list_display = ('owner', 'acc_wealth', 'acc_gpa','acc_strength','lucky')

admin.site.register(Property, PropertyAdmin)