from django.apps import AppConfig


class LoveliveConfig(AppConfig):
    name = 'lovelive'
