from django.db import models
from django.utils import timezone


# User class for built-in authentication module
from django.contrib.auth.models import User

class Profile(models.Model):
    owner = models.OneToOneField(User)
    short_bio = models.CharField(max_length=420, default="", blank=True)
    picture = models.ImageField(upload_to="lovelive-user-profile-photos", blank=True)
    def __str__(self):
        return str(self.owner)

    @staticmethod
    def get_profile(owner):
        return Profile.objects.filter(owner=owner)

class Property(models.Model):
    # state = models.IntegerField(default=0)
    owner = models.OneToOneField(User)
    acc_wealth = models.IntegerField(default=0)
    acc_gpa = models.FloatField(default=0)
    acc_strength = models.IntegerField(default=0)
    acc_experience = models.IntegerField(default=0)
    lucky = models.FloatField(default=0)
    level = models.IntegerField(default=1)
    total_score = models.FloatField(default=0)
    def __str__(self):
        return " MyProperty " + str(self.owner) + " " + str(self.total_score)
    @staticmethod
    def get_myproperty(owner):
        return MyProperty.objects.get(owner=owner)

class PlayRole(models.Model):
    role_name = models.CharField(max_length=50, default="???")
    role_picture = models.ImageField(upload_to="lovelive-role-photos", blank=True)
    init_wealth = models.IntegerField(default=0)
    init_gpa = models.FloatField(default=0)
    init_strength = models.IntegerField(default=0)
    lucky = models.IntegerField(default=999)
    def __str__(self):
        return self.role_name

class WaitQueue(models.Model):
    wait_player_1 = models.CharField(max_length=50, default="")
    wait_player_2 = models.CharField(max_length=50, default="")
    wait_player_3 = models.CharField(max_length=50, default="")
    state = models.IntegerField(default=0)
    def __str__(self):
        return "@ player1: " + self.wait_player_1 + ", player2: " + self.wait_player_2 + ", player3: " + self.wait_player_3 + ", state: " + str(self.state)
