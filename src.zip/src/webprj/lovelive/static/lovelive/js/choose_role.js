function getRoles() {
    $.get("/lovelive/get-role")
      .done(function(data) {
      var csrftoken = getCookie('csrftoken');
      $.ajaxSetup({
        beforeSend: function(xhr, settings) {
        xhr.setRequestHeader("X-CSRFToken", csrftoken);
      }
      });

        var list = $(".role_block");
        list.empty();
        for (var i = 0; i < data.roles.length; i++) {
              var role = data.roles[i];

              var new_role = document.createElement("div");
              new_role.className = "col-xs-4";
              var role_content = document.createElement("div");
              role_content.className = "role_content";
              var role_picture = document.createElement("img");
              role_picture.className = "role_picture";
              role_picture.src = "/lovelive/photo/"+role.id;
              var role_property = document.createElement("div");
              role_property.className="role_property";
              role_property.innerHTML="Name:"+role.name+"<br>Wealth:"+role.wealth+"<br>GPA:"+role.gpa+"<br>Strength:"+role.strength+"<br>Lucky:"+role.lucky;
              var choose_btn = document.createElement("button");
              choose_btn.className = "choose_btn";
              choose_btn.value = role.id;

              choose_btn.onclick = function (){
                $.post("/lovelive/add-role",{"role_id":$(this).val()})
                .done(function(){
                  window.location = "/lovelive/home/";
                })}
              choose_btn.innerHTML = "Choose!";
              
              role_content.append(role_picture);
              role_content.append(role_property);
              role_content.append(choose_btn);
              new_role.append(role_content);
              list.append(new_role);
              }
          })
  };

function getCookie(name) {  
    var cookieValue = null;
    if (document.cookie && document.cookie != '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = jQuery.trim(cookies[i]);
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) == (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
  }
getRoles();