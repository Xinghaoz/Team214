(function() {
    var _DATA = [		// Map data：　27 * 28
        [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
        [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,0,0,0,0,0,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,1],
        [1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
        [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	],
    _OWNER_ARRAY = new Array(_DATA[0].length),
    // 0: right. 1: down. 2: left. 3: up.
	_DX = [1,0,-1,0],
	_DY = [0,-1,0,1],
    _COLOR = ['#F00','#F93','#0CF','#F9C'], // Red, Oringe
	_LIFE = 3,
	_SCORE = 0,
    _OFFSET = {x: 60, y: 10},
    _TOKEN = 0;

    var game = new Game('canvas');
    for (var i = 0; i < _OWNER_ARRAY.length; i++) {
        _OWNER_ARRAY[i] = new Array(_DATA.length);
    }

    // The start page.
    (function() {
        var stage = game.createStage();
        //logo
		// stage.createItem({
		// 	x:game.width / 2,
		// 	y:game.height * .45,
		// 	width:100,
		// 	height:100,
		// 	frames:10,
		// 	draw:function(context){
		// 		context.fillStyle = '#FFE600';
		// 		context.beginPath();
		// 		if(this.times % 2){
		// 			context.arc(this.x, this.y, this.width / 2,.20 * Math.PI,1.80 * Math.PI, false);
		// 		}else{
		// 			context.arc(this.x, this.y, this.width / 2,.01 * Math.PI,1.99 * Math.PI, false);
		// 		}
		// 		context.lineTo(this.x,this.y);
		// 		context.closePath();
		// 		context.fill();
		// 		context.fillStyle = '#000';
		// 		context.beginPath();
		// 		context.arc(this.x + 5, this.y-27, 7, 0, 2 * Math.PI, false);
		// 		context.closePath();
		// 		context.fill();
		// 	}
		// });
        // Name of the game.
		stage.createItem({
			// x:game.width/2,
			// y:game.height*.6,
            x:game.width / 2,
			y:game.height * .5,
			draw:function(context){
				context.font = 'bold 42px Helvetica';
				context.textAlign = 'center';
				context.textBaseline = 'middle';
				context.fillStyle = '#FFF';
				context.fillText('Lovelive!',this.x,this.y);
			}
		});
		// Copyright.
		stage.createItem({
			// x:game.width-12,
			// y:game.height-5,
            x:game.width - 12,
			y:game.height - 5,
			draw:function(context){
				context.font = '14px Helvetica';
				context.textAlign = 'right';
				context.textBaseline = 'bottom';
				context.fillStyle = '#AAA';
				context.fillText('© Team214',this.x,this.y);
			}
		});
        stage.bind('keydown',function(e) {
			switch(e.keyCode){
				case 13:
				case 32:
				game.nextStage();
				break;
			}
		});
    })();

    // The playing page
    (function (){
        var stage,map,times,buildings;
        var income = [0, 0, 0];
        var isInit = true;
        var players = [];
        var dice = {x: game.width - 125,
                    y: 100,
                    radius: 75,
                    width: 100,
                    height: 30};
        stage = game.createStage( {
			update:function() {
				var stage = this;
				if(stage.status == 1) {	// Normal case

				} else if(stage.status==3) {		// Pause
					if(!stage.timeout) {
						_LIFE--;
						if(_LIFE) {
							stage.resetItems();
						} else {
							game.nextStage();
							return false;
						}
					}
				}
			}
		});
        // Create buildings
        buildings = stage.createMap({
            x:_OFFSET.x,
            y:_OFFSET.y,
            data:_DATA,
            frames:8,
            draw:function(context){
                var buildingSize = 26;
                for(var j=0; j<this.y_length; j++) {
                    for(var i=0; i<this.x_length; i++) {
                        if (!this.get(i,j)) {
                            var pos = this.coord2position(i,j);
                            context.fillStyle = "#F5F5DC";
                            context.strokeRect(pos.x-buildingSize/2,pos.y-buildingSize/2,buildingSize,buildingSize);
                        }
                        if (this.owner[i][j]) {
                            context.fillStyle = this.owner[i][j].color;
                            context.fillRect(pos.x-buildingSize/2,pos.y-buildingSize/2,buildingSize,buildingSize);
                        }
                    }
                }
            }
        })
        buildings.owner = _OWNER_ARRAY;
        // Create Map
        map = stage.createMap({
			x:_OFFSET.x,
			y:_OFFSET.y,
			data:_DATA,
			cache:false, // True -> Cannot eat bean
			draw:function(context){
				for(var j=0; j<this.y_length; j++){
					for(var i=0; i<this.x_length; i++){
						var value = this.get(i,j);
						if(value){
							var code = 0;
							if(this.get(i,j-1)&&!(this.get(i-1,j-1)&&this.get(i+1,j-1)&&this.get(i-1,j)&&this.get(i+1,j))){
								if(j){
									code += 1000;
								}
							}
							if(this.get(i+1,j)&&!(this.get(i+1,j-1)&&this.get(i+1,j+1)&&this.get(i,j-1)&&this.get(i,j+1))){
								if(i<this.x_length-1){
									code += 100;
								}
							}
							if(this.get(i,j+1)&&!(this.get(i-1,j+1)&&this.get(i+1,j+1)&&this.get(i-1,j)&&this.get(i+1,j))){
								if(j<this.y_length-1){
									code += 10;
								}
							}
							if(this.get(i-1,j)&&!(this.get(i-1,j-1)&&this.get(i-1,j+1)&&this.get(i,j-1)&&this.get(i,j+1))){
								if(i){
									code += 1;
								}
							}
							if(code){
								context.lineWidth = 2;
								context.strokeStyle=value==2?"#FFF":"#e67300";
								var pos = this.coord2position(i,j);
								switch(code){
									case 1100:
									context.beginPath();
									context.arc(pos.x+this.size/2,pos.y-this.size/2,this.size/2,.5*Math.PI,1*Math.PI,false);
									context.stroke();
									context.closePath();
									break;
									case 110:
									context.beginPath();
									context.arc(pos.x+this.size/2,pos.y+this.size/2,this.size/2,Math.PI,1.5*Math.PI,false);
									context.stroke();
									context.closePath();
									break;
									case 11:
									context.beginPath();
									context.arc(pos.x-this.size/2,pos.y+this.size/2,this.size/2,1.5*Math.PI,2*Math.PI,false);
									context.stroke();
									context.closePath();
									break;
									case 1001:
									context.beginPath();
									context.arc(pos.x-this.size/2,pos.y-this.size/2,this.size/2,0,.5*Math.PI,false);
									context.stroke();
									context.closePath();
									break;
									default:
									var arr = String.prototype.split.call(code,'');
									if(+arr.pop()){
										context.beginPath();
										context.moveTo(pos.x,pos.y);
										context.lineTo(pos.x-this.size/2,pos.y);
										context.stroke();
										context.closePath();
									}
									if(+arr.pop()){
										context.beginPath();
										context.moveTo(pos.x,pos.y);
										context.lineTo(pos.x,pos.y+this.size/2);
										context.stroke();
										context.closePath();
									}
									if(+arr.pop()){
										context.beginPath();
										context.moveTo(pos.x,pos.y);
										context.lineTo(pos.x+this.size/2,pos.y);
										context.stroke();
										context.closePath();
									}
									if(+arr.pop()){
										context.beginPath();
										context.moveTo(pos.x,pos.y);
										context.lineTo(pos.x,pos.y-this.size/2);
										context.stroke();
										context.closePath();
									}
								}
							}
						}
					}
				}
			}
		});
        // Create dice. Dice should be created before the player
        stage.createItem({
            // x:game.width-200,
			// y:game.height-200,
			draw:function(context){
                context.fillStyle='red';
                context.beginPath();
                // context.arc(dice.x , dice.y, dice.radius, 0, Math.PI * 2, true);
                context.strokeRect(dice.x - 50, dice.y - 30, dice.width, dice.height);
                // context.fill();
                context.font = '24px Helvetica';
                context.textAlign = 'center';
                context.textBaseline = 'center';
                context.fillStyle = '#09F';
                context.fillText("Dice", dice.x, dice.y);
			}
		});
        stage.bind('click', function(e) {
            isInit = false;
            var point = getEventPosition(e);
            console.log("click event detected.");
            var a = point.x - dice.x;
            var b = point.y - dice.y;
            if (point && Math.sqrt(a * a + b * b) <= dice.radius) {
                var step = Math.floor(Math.random() * 6 + 1); // generate random number between 1 ~ 6.
                console.log("You got " + step);
                var m = _DATA.length;
                var n = _DATA[0].length;
                players[_TOKEN].steps += step * map.size / 2;
            } else {
                console.log("players" + "[" + _TOKEN + "]: [" + players[_TOKEN].x + ", " + players[_TOKEN].y + "]");
            }
        });
		items = stage.getItemsByType(2);
        // Create Players
        for (var i = 0; i < 3; i++) {
            thisCoord = {};
            thisColor = 'FFE600'; // Default color;
            // thisName = '';
            if (i == 0) {
                thisCoord = {x:1, y:1};
                thisColor = '#FFE600';
                thisOrientation = 2;
                thisName = "Alice";
            } else if (i == 1) {
                thisCoord = {x:map.x_length - 2, y:map.y_length - 2};
                thisColor = '#00FFFF';
                thisOrientation = 0;
                thisName = "Bob";
            } else if (i == 2) {
                thisCoord = {x:9, y:17};
                thisColor = '#DC143C';
                thisOrientation = 1;
                thisName = "Charlie";
            }
    		player = stage.createItem({
    			width:15,
    			height:15,
    			type:1,
    			location:map,
    			coord:thisCoord,
    			orientation:thisOrientation,
    			speed:2,
    			frames:10,
                token:i,
                color:thisColor,
                name:thisName,
    			update:function() {
                    if (income[this.token] != 0) {
                        var abs = Math.abs(income[this.token]);
                        var diff = 1;
                        if (abs > 10000) {
                            diff = 1111;
                        } else if (abs > 1000) {
                            diff = 111;
                        } else if (abs > 100) {
                            diff = 11;
                        } else if (abs > 10) {
                            diff = 1;
                        }
                        if (income[this.token] > 0) {
                            income[this.token] -= diff;
                            this.cash += diff;
                        } else {
                            income[this.token] += diff;
                            this.cash -= diff;
                        }
                    }
    				var coord = this.coord;
    				if (!coord.offset) {　// Reach the middle.
    					if(typeof this.control.orientation!='undefined'){
    						if(!map.get(coord.x+_DX[this.control.orientation],coord.y+_DY[this.control.orientation])){
    							this.orientation = this.control.orientation;
    						}
    					}
    					this.control = {};

                        var nextOrientation = [];
                        for (var i = 0; i < 4; i++) {
                            var val = map.get(coord.x + _DX[i], coord.y + _DY[i]);
                            if (val == 0 && Math.abs(i - this.orientation) != 2) {
                                nextOrientation.push(i);
                            }
                        }
                        var randomIndex = Math.floor(Math.random() * nextOrientation.length);
                        this.orientation = nextOrientation[randomIndex];
                        this.x += this.speed * _DX[this.orientation];
                        this.y += this.speed * _DY[this.orientation];
                        this.steps--;
                        console.log("_TOKEN = " + _TOKEN);

                        if (this.steps < Math.floor(map.size / 2)) { // < instead of <=.
                            this.steps = 0;
                            if (!isInit) {
                                _TOKEN = (_TOKEN + 1) % 3;
                            }

                            if (!isInit && !buildings.owner[coord.x][coord.y]) {
                                layer.confirm('<p style="margin-bottom:18;text-align:center;font-size:25;">Do you want to buy it for</p> <p style="margin:0;text-align:center;font-size:32;">$2000?</p>', {
                                    // skin: 'myskin',
                                    title: "This property is AVAILABLE!",
                                    skin: 'layer-ext-espresso',
                                    btn: ['Yes','No'], //
                                    area: ['300px'],
                                }, function(){
                                    var currentToken = (_TOKEN + 2) % 3;
                                    // players[currentToken].cash -= 2000;
                                    income[currentToken] = -2000;
                                    buildings.owner[coord.x][coord.y] = players[currentToken]; // Minus 1
                                    layer.msg("This property is now belong to [" + buildings.owner[coord.x][coord.y].name + "]", {
                                        // skin: 'myskin',
                                        skin:'layer-ext-espresso',
                                        icon: 1,
                                        time: 750,
                                    });
                                });
                            } else if (!isInit) {
                                var currentToken = (_TOKEN + 2) % 3;
                                layer.msg("You've been charged by [" + buildings.owner[coord.x][coord.y].name + "]" + 'for</p> <p style="margin:0;text-align:center;font-size:32;">$2000</p>', {
                                    // skin: 'myskin',
                                    skin:'layer-ext-espresso',
                                    icon: 1,
                                    time: 750,
                                });
                                income[buildings.owner[coord.x][coord.y].token] += 2000;
                                income[currentToken] -= 2000;
                            }
                        } else {
                            // this.steps = 0;
                        }
    				} else {
                        // Go util step got 0.
                        if (this.steps > 0) {
                            console.log(this.steps);
        					this.x += this.speed*_DX[this.orientation];
        					this.y += this.speed*_DY[this.orientation];
                            this.steps--;
                            if (this.steps == 0) {
                                if (coord.offset) {
                                    this.steps++;
                                }
                            }
                        } else {
                            // console.log("Stop at " + "[" + this.coord.x + ", " + this.coord.y + "]");
                        }
    				}
    			},
    			draw:function(context){
    				context.fillStyle = this.color;
    				context.beginPath();
    				if(stage.status != 3){	// Normal state of the player
                        	context.arc(this.x, this.y, this.width / 2, 0, 2 * Math.PI, false);
    					// if(this.times % 2){
    					// 	context.arc(this.x,this.y,this.width/2,(.5*this.orientation+.20)*Math.PI,(.5*this.orientation-.20)*Math.PI,false);
    					// }else{
    					// 	context.arc(this.x,this.y,this.width/2,(.5*this.orientation+.01)*Math.PI,(.5*this.orientation-.01)*Math.PI,false);
    					// }
    				}else{	// Player is being consumed by NPC
    					if(stage.timeout) {
    						context.arc(this.x,this.y,this.width/2,(.5*this.orientation+1-.02*stage.timeout)*Math.PI,(.5*this.orientation-1+.02*stage.timeout)*Math.PI,false);
    					}
    				}
    				context.lineTo(this.x,this.y);
    				context.closePath();
    				context.fill();
    			}
    		});
            players.push(player);
        }
        stage.createItem({
			x:game.width - 300,
			y:250,
			frames:25,
            draw:function(context){
                for (var i = 0; i < players.length; i++) {
    				context.font = '24px Comic Sans MS';
    				context.textAlign = 'left';
    				context.textBaseline = 'center';
    				// context.fillStyle = '#09F';
                    context.fillStyle = players[i].color;
                    context.fillText("Player" + i + ": " + players[i].name, this.x, this.y + i * 100);
    				context.fillText("cash: $" + players[i].cash, this.x, this.y + i * 100 + 32);
    			}
            }
		});
    })();
    game.init();

})();

function getEventPosition(ev){
    var x, y;
    if (ev.layerX || ev.layerX == 0) {
        x = ev.layerX;
        y = ev.layerY;
    } else if (ev.offsetX || ev.offsetX == 0) { // Opera
        x = ev.offsetX;
        y = ev.offsetY;
    }
    return {x: x, y: y};
}
