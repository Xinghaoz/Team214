(function() {
    var _DATA = [		// Map data：　27 * 28
        [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
        [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,0,0,0,0,0,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,1],
        [1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
        [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
	],
    _BUILDING_DATA = [
        [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
        [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,0,0,0,0,0,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,1],
        [1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1],
        [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
        [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
    ],
    // 0: right. 1: down. 2: left. 3: up.
	_DX = [1,0,-1,0],
	_DY = [0,-1,0,1];
    _COLOR = ['#F00','#F93','#0CF','#F9C'], // Red, Oringe
	_LIFE = 3,
	_SCORE = 0;
    _OFFSET = {x: 60, y: 10};
    _TOKEN = 0;

    var game = new Game('canvas');

    // The start page.
    (function() {
        var stage = game.createStage();
        //logo
		stage.createItem({
			x:game.width / 2,
			y:game.height * .45,
			width:100,
			height:100,
			frames:10,
			draw:function(context){
				context.fillStyle = '#FFE600';
				context.beginPath();
				if(this.times % 2){
					context.arc(this.x, this.y, this.width / 2,.20 * Math.PI,1.80 * Math.PI, false);
				}else{
					context.arc(this.x, this.y, this.width / 2,.01 * Math.PI,1.99 * Math.PI, false);
				}
				context.lineTo(this.x,this.y);
				context.closePath();
				context.fill();
				context.fillStyle = '#000';
				context.beginPath();
				context.arc(this.x + 5, this.y-27, 7, 0, 2 * Math.PI, false);
				context.closePath();
				context.fill();
			}
		});
        // Name of the game.
		stage.createItem({
			// x:game.width/2,
			// y:game.height*.6,
            x:game.width / 2,
			y:game.height * .6,
			draw:function(context){
				context.font = 'bold 42px Helvetica';
				context.textAlign = 'center';
				context.textBaseline = 'middle';
				context.fillStyle = '#FFF';
				context.fillText('Lovelive!',this.x,this.y);
			}
		});
		// Copyright.
		stage.createItem({
			// x:game.width-12,
			// y:game.height-5,
            x:game.width - 12,
			y:game.height - 5,
			draw:function(context){
				context.font = '14px Helvetica';
				context.textAlign = 'right';
				context.textBaseline = 'bottom';
				context.fillStyle = '#AAA';
				context.fillText('© Team214',this.x,this.y);
			}
		});
        stage.bind('keydown',function(e) {
			switch(e.keyCode){
				case 13:
				case 32:
				game.nextStage();
				break;
			}
		});
    })();

    // The playing page
    (function (){
        var stage,map,goods,beans,times,buildings;
        var players = [];
        var dice = {x: game.width - 125,
                    y: 100,
                    radius: 75,
                    width: 50,
                    height: 50};
        stage = game.createStage( {
			update:function() {
				var stage = this;
				if(stage.status == 1) {	// Normal case

				} else if(stage.status==3) {		// Pause
					if(!stage.timeout) {
						_LIFE--;
						if(_LIFE) {
							stage.resetItems();
						} else {
							game.nextStage();
							return false;
						}
					}
				}
			}
		});
        // Goods
		goods = {
			'1,3':1,
			'26,3':1,
			'1,23':1,
			'26,23':1
		};
        // beans
        beans = stage.createMap({
            x:_OFFSET.x,
            y:_OFFSET.y,
            data:_DATA,
            frames:8,
            draw:function(context){
                for(var j=0; j<this.y_length; j++) {
                    for(var i=0; i<this.x_length; i++) {
                        if(!this.get(i,j)) {
                            var pos = this.coord2position(i,j);
                            context.fillStyle = "#F5F5DC";
                            if(goods[i+','+j]) {
                                // context.beginPath();
                                // context.arc(pos.x,pos.y,3+this.times%2,0,2*Math.PI,true);
                                // context.fill();
                                // context.closePath();
                            }else {
                                // context.fillRect(pos.x-2,pos.y-2,4,4);
                            }
                        }
                    }
                }
            }
        });
        // Create buildings
        buildings = stage.createMap({
            x:_OFFSET.x,
            y:_OFFSET.y,
            data:_DATA,
            frames:8,
            draw:function(context){
                for(var j=0; j<this.y_length; j++) {
                    for(var i=0; i<this.x_length; i++) {
                        if(!this.get(i,j)) {
                            var pos = this.coord2position(i,j);
                            context.fillStyle = "#F5F5DC";
                            context.strokeRect(pos.x-7.5,pos.y-7.5,15,15);
                        }
                    }
                }
            }
        })
        buildings.owner = _BUILDING_DATA;
        // Create Map
        map = stage.createMap({
			x:_OFFSET.x,
			y:_OFFSET.y,
			data:_DATA,
			cache:false, // True -> Cannot eat bean
			draw:function(context){
				for(var j=0; j<this.y_length; j++){
					for(var i=0; i<this.x_length; i++){
						var value = this.get(i,j);
						if(value){
							var code = 0;
							if(this.get(i,j-1)&&!(this.get(i-1,j-1)&&this.get(i+1,j-1)&&this.get(i-1,j)&&this.get(i+1,j))){
								if(j){
									code += 1000;
								}
							}
							if(this.get(i+1,j)&&!(this.get(i+1,j-1)&&this.get(i+1,j+1)&&this.get(i,j-1)&&this.get(i,j+1))){
								if(i<this.x_length-1){
									code += 100;
								}
							}
							if(this.get(i,j+1)&&!(this.get(i-1,j+1)&&this.get(i+1,j+1)&&this.get(i-1,j)&&this.get(i+1,j))){
								if(j<this.y_length-1){
									code += 10;
								}
							}
							if(this.get(i-1,j)&&!(this.get(i-1,j-1)&&this.get(i-1,j+1)&&this.get(i,j-1)&&this.get(i,j+1))){
								if(i){
									code += 1;
								}
							}
							if(code){
								context.lineWidth = 2;
								context.strokeStyle=value==2?"#FFF":"#09C";
								var pos = this.coord2position(i,j);
								switch(code){
									case 1100:
									context.beginPath();
									context.arc(pos.x+this.size/2,pos.y-this.size/2,this.size/2,.5*Math.PI,1*Math.PI,false);
									context.stroke();
									context.closePath();
									break;
									case 110:
									context.beginPath();
									context.arc(pos.x+this.size/2,pos.y+this.size/2,this.size/2,Math.PI,1.5*Math.PI,false);
									context.stroke();
									context.closePath();
									break;
									case 11:
									context.beginPath();
									context.arc(pos.x-this.size/2,pos.y+this.size/2,this.size/2,1.5*Math.PI,2*Math.PI,false);
									context.stroke();
									context.closePath();
									break;
									case 1001:
									context.beginPath();
									context.arc(pos.x-this.size/2,pos.y-this.size/2,this.size/2,0,.5*Math.PI,false);
									context.stroke();
									context.closePath();
									break;
									default:
									var arr = String.prototype.split.call(code,'');
									if(+arr.pop()){
										context.beginPath();
										context.moveTo(pos.x,pos.y);
										context.lineTo(pos.x-this.size/2,pos.y);
										context.stroke();
										context.closePath();
									}
									if(+arr.pop()){
										context.beginPath();
										context.moveTo(pos.x,pos.y);
										context.lineTo(pos.x,pos.y+this.size/2);
										context.stroke();
										context.closePath();
									}
									if(+arr.pop()){
										context.beginPath();
										context.moveTo(pos.x,pos.y);
										context.lineTo(pos.x+this.size/2,pos.y);
										context.stroke();
										context.closePath();
									}
									if(+arr.pop()){
										context.beginPath();
										context.moveTo(pos.x,pos.y);
										context.lineTo(pos.x,pos.y-this.size/2);
										context.stroke();
										context.closePath();
									}
								}
							}
						}
					}
				}
			}
		});
        // Create dice. Dice should be created before the player
        stage.createItem({
            // x:game.width-200,
			// y:game.height-200,
			draw:function(context){
                context.fillStyle='red';
                context.beginPath();
                // context.arc(dice.x , dice.y, dice.radius, 0, Math.PI * 2, true);
                context.rect(dice.x, dice.y, dice.width, dice.height);
                context.fill();
			}
		});
        stage.bind('click', function(e) {
            var point = getEventPosition(e);
            console.log("click event detected.");
            var a = point.x - dice.x;
            var b = point.y - dice.y;
            if (point && Math.sqrt(a * a + b * b) <= dice.radius) {
                var step = Math.floor(Math.random() * 6 + 1); // generate random number between 1 ~ 6.
                console.log("You got " + step);
                var m = _DATA.length;
                var n = _DATA[0].length;
                players[_TOKEN].steps += step * map.size / 2;
            } else {
                console.log("players" + "[" + _TOKEN + "]: [" + players[_TOKEN].x + ", " + players[_TOKEN].y + "]");
            }
        });
		items = stage.getItemsByType(2);
        // Create Players
        for (var i = 0; i < 3; i++) {
            thisCoord = {};
            thisColor = 'FFE600'; // Default color;
            if (i == 0) {
                thisCoord = {x:1, y:1};
                thisColor = '#FFE600';
                thisOrientation = 2;
            } else if (i == 1) {
                thisCoord = {x:map.x_length - 2, y:map.y_length - 2};
                thisColor = '#00FFFF';
                thisOrientation = 0;
            } else if (i == 2) {
                thisCoord = {x:9, y:17};
                thisColor = '#DC143C';
                thisOrientation = 1;
            }
    		player = stage.createItem({
    			width:15,
    			height:15,
    			type:1,
    			location:map,
    			coord:thisCoord,
    			orientation:thisOrientation,
    			speed:2,
    			frames:10,
                token:i,
                color:thisColor,
    			update:function() {
    				var coord = this.coord;
    				if (!coord.offset) {　// Reach the middle.
    					if(typeof this.control.orientation!='undefined'){
    						if(!map.get(coord.x+_DX[this.control.orientation],coord.y+_DY[this.control.orientation])){
    							this.orientation = this.control.orientation;
    						}
    					}
    					this.control = {};

                        var nextOrientation = [];
                        for (var i = 0; i < 4; i++) {
                            var val = map.get(coord.x + _DX[i], coord.y + _DY[i]);
                            if (val == 0 && Math.abs(i - this.orientation) != 2) {
                                nextOrientation.push(i);
                            }
                        }
                        var randomIndex = Math.floor(Math.random() * nextOrientation.length);
                        this.orientation = nextOrientation[randomIndex];
                        this.x += this.speed * _DX[this.orientation];
                        this.y += this.speed * _DY[this.orientation];
                        this.steps--;

                        if (this.steps < Math.floor(map.size / 2)) { // < instead of <=.
                            console.log("steps = " + this.steps + ", map.size = " + map.size);
                            this.steps = 0;
                            _TOKEN = (_TOKEN + 1) % 3;

                            layer.confirm('Do you want to purchase this area?' + "[" + coord.x + ", " + coord.y + "]"+  "Owner: " + buildings.owner[coord.x][coord.y], {
                                // skin: 'myskin',
                                title: "Here is an empty area!",
                                skin: 'layer-ext-espresso',
                                btn: ['Yes','No'] //
                            }, function(){
                                layer.msg("You've purchased this area.", {
                                    // skin: 'myskin',
                                    skin:'layer-ext-espresso',
                                    icon: 1,
                                    time: 750,
                                });
                            }, function(){
                                layer.msg('也可以这样', {
                                    skin:'layer-ext-espresso',
                                    time: 20000, //20s后自动关闭
                                    btn: ['明白了', '知道了']
                                });
                            });
                        } else {
                            // this.steps = 0;
                        }
    				} else {
    					if(!beans.get(this.coord.x,this.coord.y)){	// Eat the bean
    						_SCORE++;
    						beans.set(this.coord.x,this.coord.y,1);
    						if(goods[this.coord.x+','+this.coord.y]){	// Eat the super bean
    							items.forEach(function(item){
    								if(item.status==1||item.status==3){	// Set the NPC to ghost state
    									item.timeout = 450;
    									item.status = 3;
    								}
    							});
    						}
    					}

                        // Go util step got 0.
                        if (this.steps > 0) {
                            console.log(this.steps);
        					this.x += this.speed*_DX[this.orientation];
        					this.y += this.speed*_DY[this.orientation];
                            this.steps--;
                            if (this.steps == 0) {
                                if (coord.offset) {
                                    this.steps++;
                                }
                                // else {
                                //     _TOKEN = (_TOKEN + 1) % 3;
                                //     console.log("Stop at " + "[" + this.coord.x + ", " + this.coord.y + "]");
                                //     positions = map.coord2position(this.coord.x, this.coord.y);
                                //     console.log("pos.x = " + positions.x + ", pos.y = " + positions.y);
                                // }
                                // layer.open({
                				// 	type: 1,
                				// 	title: 'Event',
                				// 	area: ['250px', '150px'],
                				// 	shadeClose: true, //
                				// 	content: '\<\div style="padding:20px;">[' + this.coord.x +', ' + this.coord.y + ']' +
                				// 		     '\<\/div>'
                				// });
                            }
                        } else {
                            // console.log("Stop at " + "[" + this.coord.x + ", " + this.coord.y + "]");
                        }
    				}
    			},
    			draw:function(context){
    				context.fillStyle = this.color;
    				context.beginPath();
    				if(stage.status != 3){	// Normal state of the player
                        	context.arc(this.x,this.y,this.width/2,(.5*this.orientation+.01)*Math.PI,(.5*this.orientation-.01)*Math.PI,false);
    					// if(this.times % 2){
    					// 	context.arc(this.x,this.y,this.width/2,(.5*this.orientation+.20)*Math.PI,(.5*this.orientation-.20)*Math.PI,false);
    					// }else{
    					// 	context.arc(this.x,this.y,this.width/2,(.5*this.orientation+.01)*Math.PI,(.5*this.orientation-.01)*Math.PI,false);
    					// }
    				}else{	// Player is being consumed by NPC
    					if(stage.timeout) {
    						context.arc(this.x,this.y,this.width/2,(.5*this.orientation+1-.02*stage.timeout)*Math.PI,(.5*this.orientation-1+.02*stage.timeout)*Math.PI,false);
    					}
    				}
    				context.lineTo(this.x,this.y);
    				context.closePath();
    				context.fill();
    			}
    		});
            players.push(player);
        }
    })();
    game.init();

})();

function getEventPosition(ev){
    var x, y;
    if (ev.layerX || ev.layerX == 0) {
        x = ev.layerX;
        y = ev.layerY;
    } else if (ev.offsetX || ev.offsetX == 0) { // Opera
        x = ev.offsetX;
        y = ev.offsetY;
    }
    return {x: x, y: y};
}
