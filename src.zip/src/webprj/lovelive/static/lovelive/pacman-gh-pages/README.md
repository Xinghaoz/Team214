# Pacman 吃豆游戏

- 演示分支：gh-pages

- 代码发布分支：master

- 项目演示(DEMO)地址：http://passer-by.com/pacman/

### 版权
本游戏由 [passer-by.com](http://passer-by.com/) 制作，请尊重作者，引用请注明来源。

功能

- [x] 地图绘制
- [x] 玩家控制
- [x] NPC根据玩家坐标实时自动寻径
- [x] 吃豆积分系统
- [x] 能量豆功能
- [ ] 特殊物品记分
- [ ] 多关卡
