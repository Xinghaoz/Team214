from django.shortcuts import render, redirect, get_object_or_404
from django.core.urlresolvers import reverse
from django.http import HttpResponse, Http404
from django.http import JsonResponse
from django.core.exceptions import ObjectDoesNotExist
from django.db import transaction

from django.utils import timezone

# import time
import datetime
from datetime import tzinfo, timedelta, datetime
import pytz

from django.core import serializers
import json
# Decorator to use built-in authentication system
from django.contrib.auth.decorators import login_required

# Used to create and manually log in a user
from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate

from django.contrib.auth.views import password_reset, password_reset_confirm
from django.contrib.auth.forms import PasswordResetForm
#Helper function to guess a MIME type from a file name
from mimetypes import guess_type
from django.core.mail import send_mail
from django.contrib.auth.tokens import default_token_generator


from lovelive.models import *
from lovelive.forms import *



def first_page(request):

    return render(request, 'lovelive/first_page.html', )


@login_required
def home(request):
    me = User.objects.get(username=request.user.username)
    myproperty = Property.objects.get(owner = request.user)
    context = {
        'myprofile' : Profile.objects.get(owner=request.user),
        'myproperty' : Property.objects.get(owner = request.user),
        'me' : me,
    }
    return render(request, 'lovelive/home_page.html', context)


@login_required
@transaction.atomic
def edit_profile(request):
    profile_to_edit = get_object_or_404(Profile, owner=request.user)


    if request.method == 'GET':
        profileform = ProfileForm(instance=profile_to_edit)  # Creates form from the
        context = {'profileform' : profileform,         # existing profile.
                   'changepasswordform' : ChangePasswordForm(), }
        return render(request, 'lovelive/edit_profile.html', context)

    new_profile = ProfileForm(request.POST, request.FILES, instance=profile_to_edit)

    if not new_profile.is_valid():
        context = {'profileform' : new_profile,}
        return render(request, 'lovelive/edit_profile.html', context)

    new_profile.save()
    return redirect(reverse('home'))

@login_required
@transaction.atomic
def change_password_in_profile(request):
    changepasswordform = ChangePasswordForm(request.POST)
    if not changepasswordform.is_valid():
        profile_to_edit = get_object_or_404(Profile, owner=request.user)
        profileform = ProfileForm(instance=profile_to_edit)  # Creates form from the
        context = {'profileform' : profileform,         # existing profile.
                   'changepasswordform' : changepasswordform, }
        return render(request, 'lovelive/edit_my_profile.html', context)
    user_change_password = request.user
    password_to_be_set = changepasswordform.cleaned_data['password1']
    user_change_password.set_password(password_to_be_set)
    user_change_password.save()
    login(request, user_change_password)
    return redirect(reverse('home'))

@login_required
def get_profile_photo(request):
    profile_get_photo = get_object_or_404(Profile, owner=request.user)
    if not profile_get_photo.picture:
        raise Http404
    content_type = guess_type(profile_get_photo.picture.name)
    return HttpResponse(profile_get_photo.picture, content_type=content_type)

@login_required
def get_other_profile_photo(request, id):
    print("get photo")
    other_user = User.objects.get(id = id)
    print("get photo")
    profile_get_photo = get_object_or_404(Profile, owner=other_user)
    print("get photo")
    if not profile_get_photo.picture:
        raise Http404
    content_type = guess_type(profile_get_photo.picture.name)
    print("get photo")
    return HttpResponse(profile_get_photo.picture, content_type=content_type)

@transaction.atomic
def register(request):
    context = {}
    # Just display the registration form if this is a GET request
    if request.method == 'GET':
        context['registrationform'] = RegistrationForm()
        return render(request, 'lovelive/register_page.html', context)
    registrationform = RegistrationForm(request.POST)
    context['registrationform'] = registrationform

    if not registrationform.is_valid():
        return render(request, 'lovelive/register_page.html', context)

    new_user = User.objects.create_user(username=registrationform.cleaned_data['username'], \
                                        email=registrationform.cleaned_data['email1'], \
                                        password=registrationform.cleaned_data['password1'])
    new_user.is_active = False
    new_user.save()
    #create a blank profile
    new_profile = Profile(owner=new_user)
    new_profile.save()
    #create a blank my property
    new_myproperty = Property(owner=new_user)
    new_myproperty.save()

    #token
    token = default_token_generator.make_token(new_user)

    #email_body
    email_body = """
        Welcome to lovelive, click the link below to verify your email address:
        http://%s%s
    """ % (request.get_host(), reverse('confirm', args=(new_user.username, token, )))
    #

    send_mail(subject = "verify your email",
              message = email_body,
              from_email="lovelive-regis-service@lovelive.com",
              recipient_list = [new_user.email])

    context['username'] = new_user.username
    context['email'] = new_user.email
    context['verification_error'] = 0
    return render(request, 'lovelive/wait_to_be_activated.html', context)

@transaction.atomic
def confirm(request, username, token):
    context = {}
    try:
        new_activated_user = User.objects.get(username=username)
    except User.DoesNotExist:
        context['verification_error'] = 1
        return render(request, 'lovelive/wait_to_be_activated.html', context)
    token_2 = default_token_generator.make_token(new_activated_user)
    if new_activated_user.is_active == True:
        return redirect(reverse('home'))
    else:
        if token_2 == token:
            new_activated_user.is_active = True
            new_activated_user.save()
        else:
            context['verification_error'] = 1
            return render(request, 'lovelive/wait_to_be_activated.html', context)

    # Logs in & redirects
    login(request, new_activated_user)
    # redirect to select role
    return redirect('/lovelive/choose-role')

@login_required
def choose_role(request):
    context={}
    return render(request, 'lovelive/choose_role.html', context)

@login_required
def get_role(request):
    context={}
    roles=PlayRole.objects.order_by('id')
    print(roles)
    context['roles']=roles
    return render(request, 'lovelive/roles.json', context, content_type='application/json')

@login_required
def add_role(request):
    context={}
    user = User.objects.get(username=request.user)
    myproperty = get_object_or_404(Property, owner = user)
    print(myproperty)
    role = get_object_or_404(PlayRole, id = request.POST['role_id'])
    print(role)
    myproperty.acc_wealth = role.init_wealth
    myproperty.acc_gpa =  role.init_gpa
    myproperty.acc_strength = role.init_strength
    myproperty.lucky = role.lucky
    myproperty.total_score = myproperty.acc_wealth(1+myproperty.acc_gpa/5+myproperty.acc_strength/100)
    myproperty.save()

    return redirect(reverse('home'))

@login_required
def get_photo(request,id):
    role = get_object_or_404(PlayRole, id = id)
    if not role.role_picture:
        raise Http404
    content_type = guess_type (role.role_picture.name)
    return HttpResponse(role.role_picture, content_type = content_type)

@transaction.atomic
def reset_password(request):

    return password_reset(request,
            template_name='lovelive/password_reset/password_reset_form.html',
            email_template_name='lovelive/password_reset/password_reset_email.html',
            password_reset_form=PasswordResetForm,
            token_generator=default_token_generator,
            post_reset_redirect='/lovelive/user/password/reset/done/')

@login_required
def scoreboard(request):
    me = User.objects.get(username=request.user)
    all_users_scores = Property.objects.order_by('total_score')
    first_50_users_scores = all_users_scores[0:49]
    context={'me' : me,
            'first_50_users_scores' : first_50_users_scores,
            }
    return render(request, 'lovelive/scoreboard.html', context)

def wait_for_other_user(request):
    return render(request, 'lovelive/waiting.html')

def game(request):
    return render(request, 'lovelive/game.html', {})
#------------------------------------ WAIT ROOM PART Begin--------------------------
@login_required
def choose_map(request):
    context={}
    return render(request, 'lovelive/choose_map.html', context)

@login_required
@transaction.atomic
def join_wait_queue(request):
    try:
        waitqueue_now = get_object_or_404(WaitQueue, id=4)
        if (waitqueue_now.wait_player_1 == request.user.username) or \
           (waitqueue_now.wait_player_2 == request.user.username) or \
           (waitqueue_now.wait_player_3 == request.user.username):
           print("user has already join in")
           return redirect(reverse('check-if-other-user-join-in'))
        print(waitqueue_now)
        if waitqueue_now.state == 1:
            waitqueue_now.wait_player_2 = request.user.username
            waitqueue_now.state = 2
        elif waitqueue_now.state == 2:
            waitqueue_now.wait_player_3 = request.user.username
            waitqueue_now.state = 3
            #game should begin now
        elif waitqueue_now.state == 3:
            waitqueue_now.wait_player_2 = ""
            waitqueue_now.wait_player_3 = ""
            #begin a new round
            waitqueue_now.wait_player_1 = request.user.username
            waitqueue_now.state = 1
        else:
            #something wrong
            return redirect(reverse('error-lovelive'))
        waitqueue_now.save()
        print("people start joining the queue:", waitqueue_now)
        return redirect(reverse('check-if-other-user-join-in'))
    except:
        # if the wait queue has no been created
        new_waitqueue = WaitQueue(wait_player_1 = request.user.username, state = 1)
        new_waitqueue.save()
        print("initializing")
        print(new_waitqueue)
    return redirect(reverse('check-if-other-user-join-in'))
@login_required
@transaction.atomic
def check_if_other_user_join_in(request):
    print("now check if other user join in")
    players = []
    try:
        waitqueue_now = get_object_or_404(WaitQueue, id=4)
        begin_status = 0
        if waitqueue_now.state >= 1:
            player1_username = waitqueue_now.wait_player_1
            player1 = get_object_or_404(User, username = player1_username)
            players.append(player1)
            if waitqueue_now.state >= 2:
                player2_username = waitqueue_now.wait_player_2
                player2 = get_object_or_404(User, username = player2_username)
                players.append(player2)
                if waitqueue_now.state >= 3:
                    player3_username = waitqueue_now.wait_player_3
                    player3 = get_object_or_404(User, username = player3_username)
                    players.append(player3)
                    begin_status = 1
                    print("now check if other user join in ---- last person... game starting now... redirecting to starting game...")
        print("now check if other user join in ---- begin status:", begin_status)
        print("now check if other user join in ---- players:", players)
        context = {'players' : players,
                   'begin_status' : begin_status,}
    except ObjectDoesNotExist:
        return redirect(reverse('error-lovelive'))
    return render(request, 'lovelive/wait_queue.json', context, content_type="application/json")
@login_required
@transaction.atomic
def wait_queue_full_start_game(request):
    # try:
    #     waitqueue_now = get_object_or_404(WaitQueue, id=1)
    #     print(waitqueue_now)
    #     return HttpResponse("begin")
    # except:
    #     return redirect(reverse('error-lovelive'))
    return HttpResponse("test")

#------------------------------------ WAIT ROOM PART End--------------------------
def error_lovelive(request):
    return HttpResponse("error")
